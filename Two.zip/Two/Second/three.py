y = ["Waleed","Shahzob","Ayaz","Mustansir","Rashid","Sabahat","A.Rafay","Anas","Shozab","Ghazali"]
x = input("Enter Student name: ")
p=0

for i in y:
    p+=1
    if(i==x):
        print(i," is in location: ",p)