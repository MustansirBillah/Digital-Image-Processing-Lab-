x= {}
x["Mustansir"] = 1.5
x["Shahzob"] = 3
x["Anas"] = 2.0
x["Sabahat"] = 2.45
x["Rabi Ahmed"] = 2.3
y = input("Enter a Name: ")
if y in x.keys():
    x[y] = x.get(y)+1
    print(y," Exists! with CGPA of: ",x.get(y))
elif y not in x.keys():
    x[y] = 0
print(x)