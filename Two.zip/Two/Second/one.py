x= [5,9,7,10]
y = [10,5,3]
print(x[0:4])
print(x[0:4:2])
print(x[::-1])
x.append(13)
print(x)
x.append(y)
print(x)