x = {}
x["Ayaz"] = 3.4
x["Rashid"] = 0
x["Mustansir"] = 1.5
x["Shahzob"] = 3
x["Anas"] = 2.0
x["Sabahat"] = 2.45
x["Rabi Ahmed"] = 2.3
p=0
print("People who Failed: \n")
for i in x.keys():
    p+=1
    if(x[i]<=2.5):
        print(p,". ",i," has failed with CGPA: ",x[i])
