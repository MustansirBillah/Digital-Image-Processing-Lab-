y= (8,9,10)
print(y)
y= (6,9,2)
print(y)
x = list(y)
x.append(6)
print(x)
for i in x:
    print(i)
for i in y:
    print(i)