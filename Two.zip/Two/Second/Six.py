x = []
y = input()